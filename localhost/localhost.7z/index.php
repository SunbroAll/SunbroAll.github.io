<form action="action.php" method="post">
    <input name="name" type="text" size="200" value="Вася"><br>
    <p><input type="submit" /></p>
</form>